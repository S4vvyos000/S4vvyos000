# 🌿 The Garden Codex

_"Gardens grow from broken roots. But only when arranged with order do they yield the path to knowledge."_

## GARDEN CODEX: L1A

y0u_5h0uld_grow_0n3_p@ttern:
HZXNG VVTRV XRKSV VRTVG YVMHG NVHGL NVHGP VVVGL

root_layers: ϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗϗ

GRID:
13 | 8 | 21 | 5 | 18
1A | 17 | 9 | 4 | 26
Y3 | 0F | 0A | 7D | 2C
K@ | 1E | 0X | 3E | 44
1Z | 10 | 11 | 01 | 3B

LITTLE LEAF: 01001100 01101001 01101110 01101011
SHOOTS TWICE IN MIRROR (L-M): "v2lnZnZ3YmlodGZ0d25qYg=="

Tr@ce st3ps 0f "Z3u5" in the order of wind, not fire.
You’ll find G1t where they collide.

:: "Use the wind to shift the vines, ROTating will not suffice."


Once you decode the leaves... follow the next path to the second leaf.

👉 [second_leaf.txt](second_leaf.txt)
